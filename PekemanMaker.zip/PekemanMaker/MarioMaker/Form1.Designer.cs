﻿namespace MarioMaker
{
    sealed partial class Frm1
    {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur Windows Form

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fichierToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.nouveauToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ouvrirToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripSeparator();
            this.enregistrerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
            this.quitterToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.paramètreToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.backgroundToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.foregroundToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.collisionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.actualLayerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.backgroundToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.foregroundToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.collisionToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.collisionRemoveToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripSeparator();
            this.eventsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pokemonToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pokedexToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pokemartToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem4 = new System.Windows.Forms.ToolStripSeparator();
            this.npcToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.spawnToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem5 = new System.Windows.Forms.ToolStripSeparator();
            this.dimensionsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tilesetToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aideToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.àProposToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.RefreshMap = new System.Windows.Forms.Timer(this.components);
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.PnlMap = new MarioMaker.Map();
            this.PnlSprite = new System.Windows.Forms.FlowLayoutPanel();
            this.PctSprite = new System.Windows.Forms.PictureBox();
            this.menuStrip1.SuspendLayout();
            this.flowLayoutPanel1.SuspendLayout();
            this.PnlMap.SuspendLayout();
            this.PnlSprite.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PctSprite)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fichierToolStripMenuItem,
            this.paramètreToolStripMenuItem,
            this.aideToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(843, 24);
            this.menuStrip1.TabIndex = 5;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fichierToolStripMenuItem
            // 
            this.fichierToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.nouveauToolStripMenuItem,
            this.ouvrirToolStripMenuItem,
            this.toolStripMenuItem2,
            this.enregistrerToolStripMenuItem,
            this.toolStripMenuItem1,
            this.quitterToolStripMenuItem});
            this.fichierToolStripMenuItem.Name = "fichierToolStripMenuItem";
            this.fichierToolStripMenuItem.Size = new System.Drawing.Size(54, 20);
            this.fichierToolStripMenuItem.Text = "Fichier";
            // 
            // nouveauToolStripMenuItem
            // 
            this.nouveauToolStripMenuItem.Name = "nouveauToolStripMenuItem";
            this.nouveauToolStripMenuItem.Size = new System.Drawing.Size(130, 22);
            this.nouveauToolStripMenuItem.Text = "Nouveau";
            // 
            // ouvrirToolStripMenuItem
            // 
            this.ouvrirToolStripMenuItem.Name = "ouvrirToolStripMenuItem";
            this.ouvrirToolStripMenuItem.Size = new System.Drawing.Size(130, 22);
            this.ouvrirToolStripMenuItem.Text = "Ouvrir";
            this.ouvrirToolStripMenuItem.Click += new System.EventHandler(this.ouvrirToolStripMenuItem_Click);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(127, 6);
            // 
            // enregistrerToolStripMenuItem
            // 
            this.enregistrerToolStripMenuItem.Name = "enregistrerToolStripMenuItem";
            this.enregistrerToolStripMenuItem.Size = new System.Drawing.Size(130, 22);
            this.enregistrerToolStripMenuItem.Text = "Enregistrer";
            this.enregistrerToolStripMenuItem.Click += new System.EventHandler(this.enregistrerToolStripMenuItem_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(127, 6);
            // 
            // quitterToolStripMenuItem
            // 
            this.quitterToolStripMenuItem.Name = "quitterToolStripMenuItem";
            this.quitterToolStripMenuItem.Size = new System.Drawing.Size(130, 22);
            this.quitterToolStripMenuItem.Text = "Quitter";
            this.quitterToolStripMenuItem.Click += new System.EventHandler(this.quitterToolStripMenuItem_Click);
            // 
            // paramètreToolStripMenuItem
            // 
            this.paramètreToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.backgroundToolStripMenuItem,
            this.foregroundToolStripMenuItem,
            this.collisionToolStripMenuItem,
            this.actualLayerToolStripMenuItem,
            this.toolStripMenuItem3,
            this.eventsToolStripMenuItem,
            this.toolStripMenuItem4,
            this.npcToolStripMenuItem,
            this.spawnToolStripMenuItem,
            this.toolStripMenuItem5,
            this.dimensionsToolStripMenuItem,
            this.tilesetToolStripMenuItem});
            this.paramètreToolStripMenuItem.Name = "paramètreToolStripMenuItem";
            this.paramètreToolStripMenuItem.Size = new System.Drawing.Size(73, 20);
            this.paramètreToolStripMenuItem.Text = "Paramètre";
            // 
            // backgroundToolStripMenuItem
            // 
            this.backgroundToolStripMenuItem.Checked = true;
            this.backgroundToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked;
            this.backgroundToolStripMenuItem.Name = "backgroundToolStripMenuItem";
            this.backgroundToolStripMenuItem.Size = new System.Drawing.Size(138, 22);
            this.backgroundToolStripMenuItem.Text = "Background";
            this.backgroundToolStripMenuItem.Click += new System.EventHandler(this.backgroundToolStripMenuItem_Click);
            // 
            // foregroundToolStripMenuItem
            // 
            this.foregroundToolStripMenuItem.Checked = true;
            this.foregroundToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked;
            this.foregroundToolStripMenuItem.Name = "foregroundToolStripMenuItem";
            this.foregroundToolStripMenuItem.Size = new System.Drawing.Size(138, 22);
            this.foregroundToolStripMenuItem.Text = "Foreground";
            this.foregroundToolStripMenuItem.Click += new System.EventHandler(this.foregroundToolStripMenuItem_Click);
            // 
            // collisionToolStripMenuItem
            // 
            this.collisionToolStripMenuItem.Name = "collisionToolStripMenuItem";
            this.collisionToolStripMenuItem.Size = new System.Drawing.Size(138, 22);
            this.collisionToolStripMenuItem.Text = "Collision";
            this.collisionToolStripMenuItem.Click += new System.EventHandler(this.collisionToolStripMenuItem_Click);
            // 
            // actualLayerToolStripMenuItem
            // 
            this.actualLayerToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.backgroundToolStripMenuItem1,
            this.foregroundToolStripMenuItem1,
            this.collisionToolStripMenuItem1,
            this.collisionRemoveToolStripMenuItem});
            this.actualLayerToolStripMenuItem.Name = "actualLayerToolStripMenuItem";
            this.actualLayerToolStripMenuItem.Size = new System.Drawing.Size(138, 22);
            this.actualLayerToolStripMenuItem.Text = "Actual layer";
            // 
            // backgroundToolStripMenuItem1
            // 
            this.backgroundToolStripMenuItem1.Checked = true;
            this.backgroundToolStripMenuItem1.CheckState = System.Windows.Forms.CheckState.Checked;
            this.backgroundToolStripMenuItem1.Name = "backgroundToolStripMenuItem1";
            this.backgroundToolStripMenuItem1.Size = new System.Drawing.Size(174, 22);
            this.backgroundToolStripMenuItem1.Text = "Background";
            this.backgroundToolStripMenuItem1.Click += new System.EventHandler(this.backgroundToolStripMenuItem1_Click);
            // 
            // foregroundToolStripMenuItem1
            // 
            this.foregroundToolStripMenuItem1.Name = "foregroundToolStripMenuItem1";
            this.foregroundToolStripMenuItem1.Size = new System.Drawing.Size(174, 22);
            this.foregroundToolStripMenuItem1.Text = "Foreground";
            this.foregroundToolStripMenuItem1.Click += new System.EventHandler(this.foregroundToolStripMenuItem1_Click);
            // 
            // collisionToolStripMenuItem1
            // 
            this.collisionToolStripMenuItem1.Name = "collisionToolStripMenuItem1";
            this.collisionToolStripMenuItem1.Size = new System.Drawing.Size(174, 22);
            this.collisionToolStripMenuItem1.Text = "Collision - Add";
            this.collisionToolStripMenuItem1.Click += new System.EventHandler(this.collisionToolStripMenuItem1_Click);
            // 
            // collisionRemoveToolStripMenuItem
            // 
            this.collisionRemoveToolStripMenuItem.Name = "collisionRemoveToolStripMenuItem";
            this.collisionRemoveToolStripMenuItem.Size = new System.Drawing.Size(174, 22);
            this.collisionRemoveToolStripMenuItem.Text = "Collision - Remove";
            this.collisionRemoveToolStripMenuItem.Click += new System.EventHandler(this.collisionRemoveToolStripMenuItem_Click);
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(135, 6);
            // 
            // eventsToolStripMenuItem
            // 
            this.eventsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.pokemonToolStripMenuItem,
            this.pokedexToolStripMenuItem,
            this.pokemartToolStripMenuItem});
            this.eventsToolStripMenuItem.Name = "eventsToolStripMenuItem";
            this.eventsToolStripMenuItem.Size = new System.Drawing.Size(138, 22);
            this.eventsToolStripMenuItem.Text = "Events";
            // 
            // pokemonToolStripMenuItem
            // 
            this.pokemonToolStripMenuItem.Name = "pokemonToolStripMenuItem";
            this.pokemonToolStripMenuItem.Size = new System.Drawing.Size(125, 22);
            this.pokemonToolStripMenuItem.Text = "Pokemon";
            this.pokemonToolStripMenuItem.Click += new System.EventHandler(this.pokemonToolStripMenuItem_Click);
            // 
            // pokedexToolStripMenuItem
            // 
            this.pokedexToolStripMenuItem.Name = "pokedexToolStripMenuItem";
            this.pokedexToolStripMenuItem.Size = new System.Drawing.Size(125, 22);
            this.pokedexToolStripMenuItem.Text = "Pokedex";
            this.pokedexToolStripMenuItem.Click += new System.EventHandler(this.pokedexToolStripMenuItem_Click);
            // 
            // pokemartToolStripMenuItem
            // 
            this.pokemartToolStripMenuItem.Name = "pokemartToolStripMenuItem";
            this.pokemartToolStripMenuItem.Size = new System.Drawing.Size(125, 22);
            this.pokemartToolStripMenuItem.Text = "Pokemart";
            this.pokemartToolStripMenuItem.Click += new System.EventHandler(this.pokemartToolStripMenuItem_Click);
            // 
            // toolStripMenuItem4
            // 
            this.toolStripMenuItem4.Name = "toolStripMenuItem4";
            this.toolStripMenuItem4.Size = new System.Drawing.Size(135, 6);
            // 
            // npcToolStripMenuItem
            // 
            this.npcToolStripMenuItem.Name = "npcToolStripMenuItem";
            this.npcToolStripMenuItem.Size = new System.Drawing.Size(138, 22);
            this.npcToolStripMenuItem.Text = "Npc";
            // 
            // spawnToolStripMenuItem
            // 
            this.spawnToolStripMenuItem.Name = "spawnToolStripMenuItem";
            this.spawnToolStripMenuItem.Size = new System.Drawing.Size(138, 22);
            this.spawnToolStripMenuItem.Text = "Spawn";
            // 
            // toolStripMenuItem5
            // 
            this.toolStripMenuItem5.Name = "toolStripMenuItem5";
            this.toolStripMenuItem5.Size = new System.Drawing.Size(135, 6);
            // 
            // dimensionsToolStripMenuItem
            // 
            this.dimensionsToolStripMenuItem.Name = "dimensionsToolStripMenuItem";
            this.dimensionsToolStripMenuItem.Size = new System.Drawing.Size(138, 22);
            this.dimensionsToolStripMenuItem.Text = "Dimensions";
            // 
            // tilesetToolStripMenuItem
            // 
            this.tilesetToolStripMenuItem.Name = "tilesetToolStripMenuItem";
            this.tilesetToolStripMenuItem.Size = new System.Drawing.Size(138, 22);
            this.tilesetToolStripMenuItem.Text = "Tileset";
            // 
            // aideToolStripMenuItem
            // 
            this.aideToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.àProposToolStripMenuItem});
            this.aideToolStripMenuItem.Name = "aideToolStripMenuItem";
            this.aideToolStripMenuItem.Size = new System.Drawing.Size(43, 20);
            this.aideToolStripMenuItem.Text = "Aide";
            // 
            // àProposToolStripMenuItem
            // 
            this.àProposToolStripMenuItem.Name = "àProposToolStripMenuItem";
            this.àProposToolStripMenuItem.Size = new System.Drawing.Size(122, 22);
            this.àProposToolStripMenuItem.Text = "À propos";
            // 
            // RefreshMap
            // 
            this.RefreshMap.Enabled = true;
            this.RefreshMap.Interval = 30;
            this.RefreshMap.Tick += new System.EventHandler(this.RefreshMap_Tick);
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.flowLayoutPanel1.AutoScroll = true;
            this.flowLayoutPanel1.Controls.Add(this.PnlMap);
            this.flowLayoutPanel1.Location = new System.Drawing.Point(0, 27);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(843, 501);
            this.flowLayoutPanel1.TabIndex = 1;
            // 
            // PnlMap
            // 
            this.PnlMap.Controls.Add(this.PnlSprite);
            this.PnlMap.Location = new System.Drawing.Point(3, 3);
            this.PnlMap.MouseX = 0;
            this.PnlMap.MouseY = 0;
            this.PnlMap.Name = "PnlMap";
            this.PnlMap.PctSprite = null;
            this.PnlMap.Size = new System.Drawing.Size(840, 224);
            this.PnlMap.TabIndex = 7;
            this.PnlMap.MouseDown += new System.Windows.Forms.MouseEventHandler(this.map1_MouseDown);
            this.PnlMap.MouseMove += new System.Windows.Forms.MouseEventHandler(this.PnlMap_MouseMove);
            this.PnlMap.MouseUp += new System.Windows.Forms.MouseEventHandler(this.PnlMap_MouseUp);
            // 
            // PnlSprite
            // 
            this.PnlSprite.AllowDrop = true;
            this.PnlSprite.AutoScroll = true;
            this.PnlSprite.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.PnlSprite.Controls.Add(this.PctSprite);
            this.PnlSprite.Cursor = System.Windows.Forms.Cursors.SizeAll;
            this.PnlSprite.Location = new System.Drawing.Point(3, 3);
            this.PnlSprite.Name = "PnlSprite";
            this.PnlSprite.Size = new System.Drawing.Size(100, 100);
            this.PnlSprite.TabIndex = 6;
            this.PnlSprite.MouseDown += new System.Windows.Forms.MouseEventHandler(this.PnlSprite_MouseDown);
            this.PnlSprite.MouseUp += new System.Windows.Forms.MouseEventHandler(this.PnlSprite_MouseUp);
            // 
            // PctSprite
            // 
            this.PctSprite.BackColor = System.Drawing.SystemColors.ControlDark;
            this.PctSprite.Cursor = System.Windows.Forms.Cursors.Hand;
            this.PctSprite.Location = new System.Drawing.Point(3, 3);
            this.PctSprite.Name = "PctSprite";
            this.PctSprite.Size = new System.Drawing.Size(50, 50);
            this.PctSprite.TabIndex = 0;
            this.PctSprite.TabStop = false;
            this.PctSprite.MouseDown += new System.Windows.Forms.MouseEventHandler(this.PctSprite_MouseDown);
            // 
            // Frm1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(843, 528);
            this.Controls.Add(this.flowLayoutPanel1);
            this.Controls.Add(this.menuStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Frm1";
            this.Text = "Pekeman Maker";
            this.MouseClick += new System.Windows.Forms.MouseEventHandler(this.Frm1_MouseClick);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.flowLayoutPanel1.ResumeLayout(false);
            this.PnlMap.ResumeLayout(false);
            this.PnlSprite.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.PctSprite)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fichierToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem nouveauToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ouvrirToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem enregistrerToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem quitterToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aideToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem àProposToolStripMenuItem;
        private System.Windows.Forms.FlowLayoutPanel PnlSprite;
        private System.Windows.Forms.PictureBox PctSprite;
        private System.Windows.Forms.Timer RefreshMap;
        private System.Windows.Forms.ToolStripMenuItem paramètreToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem backgroundToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem foregroundToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem collisionToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem eventsToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem npcToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem spawnToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dimensionsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tilesetToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem5;
        private System.Windows.Forms.ToolStripMenuItem actualLayerToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem backgroundToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem foregroundToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem collisionToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem collisionRemoveToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pokemonToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pokedexToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pokemartToolStripMenuItem;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private Map PnlMap;
    }
}

