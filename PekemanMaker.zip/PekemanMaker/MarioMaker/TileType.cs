﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MarioMaker
{
    public partial class TileType : Control
    {
        [Description("Type de case"), DefaultValue(TileEnum.Plancher), DisplayName("Type de case")]
        public TileEnum Type
        {
            get;
            set;
        }

        public bool Selected = false;

        public TileType()
        {
            InitializeComponent();
        }

        protected override void OnPaint(PaintEventArgs pe)
        {
            base.OnPaint(pe);
        }

        private void TileType_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;

            /*Image img = TilesetImageGenerator.GetTile((int)Type);
            Point loc = new Point(0, 0);
            g.DrawImage(img, loc);*/

            if (Selected)
            {
                Pen pen = new Pen(Color.AliceBlue, 3);
                g.DrawLine(pen, 0, 0, 0, 32);
                g.DrawLine(pen, 0, 0, 32, 0);
                g.DrawLine(pen, 31, 0, 31, 32);
                g.DrawLine(pen, 0, 31, 32, 31);
            }
        }
    }

    public enum TileEnum
    {
        Plancher = 0,
        BriqueBrune = 1,
        CielBleu = 2,
        CoinBlock = 3,
        Nuage = 4,
        Hache = 5
    }
}
