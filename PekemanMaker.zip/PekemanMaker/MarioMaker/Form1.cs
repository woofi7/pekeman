﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MarioMaker
{
    public sealed partial class Frm1 : Form
    {
        private int[,] level = new int[32,16];
        private int _selectedTile = -1;
        private Point MouseDownLocation = new Point();

        private bool MouseDown = false;
        private int _tilesetIndex = 0;




        public Frm1()
        {
            InitializeComponent();
            DoubleBuffered = true;
            PnlMap.PctSprite = PctSprite;
        }

        private void Frm1_MouseClick(object sender, MouseEventArgs e)
        {
            if (_selectedTile == -1) return;

            Point position = this.PointToClient(Cursor.Position);
            int x = position.X / 32;
            int y = position.Y / 32;
                
            level[x, y] = _selectedTile;

            Refresh();
        }

        private void quitterToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void enregistrerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            PnlMap.SaveMap();
        }

        private void ouvrirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog1 = new OpenFileDialog
            {
                InitialDirectory = "c:\\",
                Filter = @"txt files (*.txt)|*.txt|All files (*.*)|*.*",
                FilterIndex = 2,
                RestoreDirectory = true
            };


            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    StreamReader reader = new StreamReader(openFileDialog1.FileName);

                    for (int y = 0; y < 16; y++)
                    {
                        for (int x = 0; x < 32; x++)
                        {
                            level[x,y] = reader.Read() - 48;
                        }
                        reader.Read();
                    }

                    reader.Close();

                }
                catch (Exception ex)
                {
                    MessageBox.Show(@"Error: Could not read file from disk. Original error: " + ex.Message);
                }
            }

            Refresh();
        }

        private void PnlSprite_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == System.Windows.Forms.MouseButtons.Right)
            {
                MouseDownLocation = e.Location;
            }
        }

        private void PnlSprite_MouseUp(object sender, MouseEventArgs e)
        {
            if (e.Button == System.Windows.Forms.MouseButtons.Right)
            {
                PnlSprite.Left = e.X + PnlSprite.Left - MouseDownLocation.X;
                PnlSprite.Top = e.Y + PnlSprite.Top - MouseDownLocation.Y;
            }
        }

        private void map1_MouseDown(object sender, MouseEventArgs e)
        {
            MouseDown = !MouseDown;
            if (MouseDown && e.Button == System.Windows.Forms.MouseButtons.Left)
            {
                int posX = e.X / 32;
                int posY = e.Y / 32;

                PnlMap.AddTile(posX, posY, _tilesetIndex);
            }
        }

        private void PnlMap_MouseMove(object sender, MouseEventArgs e)
        {
            if (MouseDown && e.Button == System.Windows.Forms.MouseButtons.Left)
            {
                int posX = e.X / 32;
                int posY = e.Y / 32;

                PnlMap.AddTile(posX, posY, _tilesetIndex);
            }



            PnlMap.MouseX = e.X / 32;
            PnlMap.MouseY = e.Y / 32;
        }

        private void PnlMap_MouseUp(object sender, MouseEventArgs e)
        {
            MouseDown = !MouseDown;
        }

        private void PctSprite_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == System.Windows.Forms.MouseButtons.Left)
            {
                int posX = e.X / 32;
                int posY = e.Y / 32;

                _tilesetIndex = posY * PctSprite.Height / 32 + posX;
                Console.WriteLine(_tilesetIndex);
            }
        }

        private void RefreshMap_Tick(object sender, EventArgs e)
        {
            Refresh();
            if (PctSprite.Image == null)
            {
                PctSprite.Image = PnlMap.TileSetImage;
                PctSprite.Size = PnlMap.TileSetImage.Size;

                int width = PctSprite.Size.Width;
                int height = PctSprite.Size.Height;

                if (width > 400)
                {
                    width = 400;
                }

                if (height > 500)
                {
                    height = 500;
                }

                PnlSprite.Size = new Size(width, height);
            }
        }

        private void backgroundToolStripMenuItem_Click(object sender, EventArgs e)
        {
            PnlMap.EnableBackground = !PnlMap.EnableBackground;
            backgroundToolStripMenuItem.Checked = !backgroundToolStripMenuItem.Checked;
        }

        private void foregroundToolStripMenuItem_Click(object sender, EventArgs e)
        {
            PnlMap.EnableForeground = !PnlMap.EnableForeground;
            foregroundToolStripMenuItem.Checked = !foregroundToolStripMenuItem.Checked;
        }

        private void collisionToolStripMenuItem_Click(object sender, EventArgs e)
        {
            PnlMap.EnableCollision = !PnlMap.EnableCollision;
            collisionToolStripMenuItem.Checked = !collisionToolStripMenuItem.Checked;
        }

        private void backgroundToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            PnlMap.ActualLayer = 0;
            foregroundToolStripMenuItem1.Checked = false;
            backgroundToolStripMenuItem1.Checked = false;
            collisionToolStripMenuItem1.Checked = true;
            collisionRemoveToolStripMenuItem.Checked = false;
        }

        private void foregroundToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            PnlMap.ActualLayer = 1;
            foregroundToolStripMenuItem1.Checked = true;
            backgroundToolStripMenuItem1.Checked = false;
            collisionToolStripMenuItem1.Checked = false;
            collisionRemoveToolStripMenuItem.Checked = false;
        }

        private void collisionToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            PnlMap.ActualLayer = 2;
            PnlMap.CollisionRemove = false;
            foregroundToolStripMenuItem1.Checked = false;
            backgroundToolStripMenuItem1.Checked = false;
            collisionToolStripMenuItem1.Checked = true;
            collisionRemoveToolStripMenuItem.Checked = false;
        }

        private void collisionRemoveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            PnlMap.ActualLayer = 2;
            PnlMap.CollisionRemove = true;
            collisionRemoveToolStripMenuItem.Checked = true;
            foregroundToolStripMenuItem1.Checked = false;
            backgroundToolStripMenuItem1.Checked = false;
            collisionToolStripMenuItem1.Checked = false;
        }

        private void pokemonToolStripMenuItem_Click(object sender, EventArgs e)
        {
            PnlMap.EnableEvent = !PnlMap.EnableEvent;
            pokemonToolStripMenuItem.Checked = !pokemonToolStripMenuItem.Checked;
            PnlMap.EventType = 0;
        }

        private void pokedexToolStripMenuItem_Click(object sender, EventArgs e)
        {
            PnlMap.EnableEvent = !PnlMap.EnableEvent;
            pokedexToolStripMenuItem.Checked = !pokedexToolStripMenuItem.Checked;
            PnlMap.EventType = 1;
        }

        private void pokemartToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }
    }
}
