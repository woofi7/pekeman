﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace MarioMaker
{
    public partial class Map : Panel
    {
        public MapData _mapData = new MapData();
        private Image[] sprite = new Image[2048];
        public Image TileSetImage;
        public PictureBox PctSprite { get; set; }
        public int MouseY { get; set; }
        public int MouseX { get; set; }

        private const int TileSize = 32;

        public int EventType = 0;
        public int ActualLayer = 0;
        public bool EnableBackground = true;
        public bool EnableForeground = true;
        public bool EnableCollision = false;
        public bool EnableNpc = false;
        public bool EnableSpawn = false;
        public bool CollisionRemove = false;
        public bool EnableEvent = false;

        public Map()
        {
            InitializeComponent();
            DoubleBuffered = true;
            LoadMap("../../../mapTemplate.json");
            Console.WriteLine(Width);
        }

        
        public void LoadMap(String file)
        {
            try
            {
                JsonSerializer serializer = new JsonSerializer();

                using (StreamReader sw = new StreamReader(file))
                using (JsonReader reader = new JsonTextReader(sw))
                {
                    _mapData = serializer.Deserialize<MapData>(reader);
                }
                LoadMapSprite(_mapData.TileSet);

                Width = _mapData.Size.Width * 32;
                Height = _mapData.Size.Height * 32;
            }
            catch (Exception)
            {
                //Ignored
            }
        }

        public void SaveMap()
        {

            string file = "../../../mapTemplate.json";

            JsonSerializer serializer = new JsonSerializer();

            using (StreamWriter sw = new StreamWriter(file))
            using (JsonWriter writer = new JsonTextWriter(sw))
            {
                serializer.Serialize(writer, _mapData);
            }

        }

        public void LoadMapSprite(string file)
        {
            if (file == "")
            {
                return;
            }

            TileSetImage = Image.FromFile(file);
            var width = TileSetImage.Width / TileSize;
            var heigth = TileSetImage.Height / TileSize;

            //Tileset
            for (var i = 0; i < width; i++)
            {
                for (var j = 0; j < heigth; j++)
                {
                    var index = i * heigth + j;
                    sprite[index] = new Bitmap(width, heigth);
                    var graphics = Graphics.FromImage(sprite[index]);
                    graphics.DrawImage(TileSetImage, new Rectangle(0, 0, TileSize, TileSize), new Rectangle(j * TileSize, i * TileSize, TileSize, TileSize), GraphicsUnit.Pixel);
                    graphics.Dispose();
                }
            }
        }

        private void Map_Paint(object sender, PaintEventArgs e)
        {
            try
            {
                Graphics g = e.Graphics;

                if (EnableBackground)
                    DrawBackground(g);

                if (EnableForeground)
                    DrawForeground(g);

                if (EnableCollision)
                    DrawCollision(g);

                if (EnableEvent)
                    DrawEvents(g);

                DrawCoords(g);

                if (Width != _mapData.Size.Width * 32)
                {
                    Width = _mapData.Size.Width * 32;
                Height = _mapData.Size.Height * 32;
                }
            }
            catch (Exception)
            {
                // ignored
            }
        }

        private void DrawCoords(Graphics g)
        {
            g.DrawString("x: " + MouseX, DefaultFont, Brushes.Black, 5, 10);
            g.DrawString("y: " + MouseY, DefaultFont, Brushes.Black, 5, 25);
        }

        private void DrawEvents(Graphics g)
        {
            for (int x = 0; x < _mapData.Size.Width; x++)
            {
                for (int y = 0; y < _mapData.Size.Height; y++)
                {
                    foreach (var mapDataEvent in _mapData.Events)
                    {
                        if (x >= mapDataEvent.Area.From.X && x <= mapDataEvent.Area.To.X && y >= mapDataEvent.Area.From.Y && y <= mapDataEvent.Area.To.Y)
                        {
                            int posY = y * TileSize;
                            int posX = x * TileSize;

                            SolidBrush brush = new SolidBrush(Color.Azure);
                            if (mapDataEvent.EventType == EventTypeEnum.EnterPekecenter)
                            {
                                brush = new SolidBrush(Color.FromArgb(128, 82, 1, 64));
                            }
                            else if (mapDataEvent.EventType == EventTypeEnum.EnterPokedex)
                            {
                                brush = new SolidBrush(Color.FromArgb(128, 170, 54, 23));
                            }
                            else if (mapDataEvent.EventType == EventTypeEnum.MeetPokemon)
                            {
                                brush = new SolidBrush(Color.FromArgb(128, 200, 150, 0));
                            }

                            g.FillRectangle(brush, posX, posY, TileSize, TileSize);
                        }
                    }
                }
            }
        }

        private void DrawCollision(Graphics g)
        {
            for (int x = 0; x < _mapData.Size.Width; x++)
            {
                for (int y = 0; y < _mapData.Size.Height; y++)
                {
                    if (_mapData.Layers.Collision[x * _mapData.Size.Height + y])
                    {
                        int posY = y * TileSize;
                        int posX = x * TileSize;

                        SolidBrush brush = new SolidBrush(Color.FromArgb(128, 82, 1, 0));
                        g.FillRectangle(brush, posX, posY, TileSize, TileSize);
                    }
                }
            }
        }

        private void DrawBackground(Graphics g)
        {
            for (int x = 0; x < _mapData.Size.Width; x++)
            {
                for (int y = 0; y < _mapData.Size.Height; y++)
                {
                    int tileIndexBackground = _mapData.Layers.Background[x * _mapData.Size.Width + y];

                    int posY = y * TileSize;
                    int posX = x * TileSize;

                    g.DrawImageUnscaled(sprite[tileIndexBackground], posX, posY, TileSize, TileSize);
                }
            }
        }

        private void DrawForeground(Graphics g)
        {
            for (int x = 0; x < _mapData.Size.Width; x++)
            {
                for (int y = 0; y < _mapData.Size.Height; y++)
                {
                    int tileIndexForeground = _mapData.Layers.Foreground[x * _mapData.Size.Width + y];

                    int posY = y * TileSize;
                    int posX = x * TileSize;

                    g.DrawImageUnscaled(sprite[tileIndexForeground], posX, posY, TileSize, TileSize);
                }
            }
        }

        public void AddTile(int posX, int posY, int tile)
        {
            int index = posX * _mapData.Size.Width + posY;
            if (index >= _mapData.Size.Width * _mapData.Size.Height)
            {
                return;
            }

            switch (ActualLayer)
            {
                case 0:
                    _mapData.Layers.Background[index] = tile;
                    break;
                case 1:
                    _mapData.Layers.Foreground[index] = tile;
                    break;
                case 2:
                    if (CollisionRemove)
                    {
                        _mapData.Layers.Collision[index] = false;
                    }
                    else
                    {
                        _mapData.Layers.Collision[index] = true;
                    }
                break;
            }
        }
    }

    [JsonObject(MemberSerialization.OptIn)]
    public class MapData
    {
        [JsonProperty("title")]
        public string Title { get; set; }

        [JsonProperty("tileset")]
        public string TileSet { get; set; }

        [JsonProperty("size")]
        public MapSize Size { get; set; }

        [JsonProperty("spawn")]
        public MapPos Spawn { get; set; }

        [JsonProperty("layers")]
        public MapLayers Layers { get; set; }

        [JsonProperty("events")]
        public MapEvent[] Events { get; set; }

        [JsonProperty("npc")]
        public NpcData[] Npc { get; set; }
    }

    [JsonObject(MemberSerialization.OptIn)]
    public class NpcData
    {
        [JsonProperty("name")]
        public string Name { get; set; }

        [JsonProperty("spawn")]
        public MapPos Spawn { get; set; }
    }

    [JsonObject(MemberSerialization.OptIn)]
    public class MapSize
    {
        [JsonProperty("width")]
        public int Width { get; set; }

        [JsonProperty("height")]
        public int Height { get; set; }
    }

    [JsonObject(MemberSerialization.OptIn)]
    public class MapLayers
    {
        [JsonProperty("background")]
        public int[] Background { get; set; }

        [JsonProperty("collision")]
        public bool[] Collision { get; set; }

        [JsonProperty("foreground")]
        public int[] Foreground { get; set; }
    }

    [JsonObject(MemberSerialization.OptIn)]
    public class MapEvent
    {
        [JsonProperty("eventType")]
        [JsonConverter(typeof(StringEnumConverter))]
        public EventTypeEnum EventType { get; set; }

        [JsonProperty("chances")]
        public float Chances { get; set; }

        [JsonProperty("area")]
        public MapArea Area { get; set; }
    }

    [JsonObject(MemberSerialization.OptIn)]
    public class MapArea
    {
        [JsonProperty("from")]
        public MapPos From { get; set; }

        [JsonProperty("to")]
        public MapPos To { get; set; }
    }

    [JsonObject(MemberSerialization.OptIn)]
    public class MapPos
    {
        [JsonProperty("x")]
        public int X { get; set; }

        [JsonProperty("y")]
        public int Y { get; set; }
    }
}
